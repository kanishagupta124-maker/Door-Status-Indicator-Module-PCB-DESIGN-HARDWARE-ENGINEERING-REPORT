========================================================================
DOOR STATUS INDICATOR MODULE - GERBER PRODUCTION PACKAGE
========================================================================
Student Name : Kanisha Gupta
Course       : Smart Home Hardware Automation & PCB Design
PCB CAD      : KiCad 8.0 / 7.0
Board Size   : 52.00 mm x 40.00 mm
Layer Count  : 2-Layer (1.6 mm FR4, 1 oz Cu, HASL/ENIG Lead-Free)
Soldermask   : Green (Top & Bottom)
Silkscreen   : White (Top Layer F_SilkS)

FILES INCLUDED IN THIS ARCHIVE:
- Door_Status_Indicator-F_Cu.gtl      : Top Copper Layer
- Door_Status_Indicator-B_Cu.gbl      : Bottom Copper Layer (Routed Traces)
- Door_Status_Indicator-F_SilkS.gto   : Top Silkscreen Legend
- Door_Status_Indicator-B_SilkS.gbo   : Bottom Silkscreen
- Door_Status_Indicator-F_Mask.gts    : Top Solder Mask
- Door_Status_Indicator-B_Mask.gbs    : Bottom Solder Mask
- Door_Status_Indicator-Edge_Cuts.gm1 : PCB Contour & Board Outline
- Door_Status_Indicator.drl           : Excellon NC Drill Coordinates
- README_Gerber.txt                   : Project metadata and BOM list

BILL OF MATERIALS (BOM):
1. J1  - 2-Pin Screw Terminal / Pin Header (5V & GND Input)
2. SW1 - Magnetic Reed Switch (SPDT Form-C Sensor)
3. R1  - 220 Ohm, 0.25W Resistor (Red LED Limiter)
4. R2  - 220 Ohm, 0.25W Resistor (Green LED Limiter)
5. D1  - 5mm Red Indicator LED (Door Open State)
6. D2  - 5mm Green Indicator LED (Door Closed State)
7. BZ1 - 5V Active DC Buzzer (Audio Alert)

FABRICATION RECOMMENDATION:
Compatible with JLCPCB, PCBWay, OSH Park, NextPCB standard quote systems.
========================================================================